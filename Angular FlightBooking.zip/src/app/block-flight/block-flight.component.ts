import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { ServeService } from '../serve.service';

@Component({
  selector: 'app-block-flight',
  templateUrl: './block-flight.component.html',
  styleUrls: ['./block-flight.component.css']
})
export class BlockFlightComponent implements OnInit {

  blockFlightForm = new FormGroup({
    AirlineId: new FormControl('',Validators.required),
  });

  constructor(private service:ServeService) { }

  ngOnInit(): void {
  }

  blockFlight(data:any){
    this.service.BlockFlight(data.AirlineId).subscribe((res:any) => { console.log(res);
          if(res==1){
            alert('Airline is blocked successfully');
          }
        },
        (error:HttpErrorResponse)=>{
          alert("Please Login to continue");
          
        }
    );
  }
}