import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddAirlineComponent } from './add-airline/add-airline.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { BlockFlightComponent } from './block-flight/block-flight.component';
import { BookingComponent } from './booking/booking.component';
import { CancelTicketComponent } from './cancel-ticket/cancel-ticket.component';
import { LoginUserComponent } from './login-user/login-user.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ScheduleComponent } from './schedule/schedule.component';
import { SearchByPnrComponent } from './search-by-pnr/search-by-pnr.component';
import { SearchFlightComponent } from './search-flight/search-flight.component';
import { TicketHistoryComponent } from './ticket-history/ticket-history.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';

const routes: Routes = [
  {path:'login',component:LoginComponent},
  {path:'AddFlight',component:AddAirlineComponent},
  {path:'Schedule',component:ScheduleComponent},
  {path:'Booking',component:BookingComponent},
  {path:'Search',component:SearchFlightComponent},
  {path:'tickethistory',component:TicketHistoryComponent},
  {path:'Register',component:RegisterComponent},
  {path:'user-dashboard',component:UserDashboardComponent},
  {path:'loginuser',component:LoginUserComponent},
  {path:'admin-dashboard',component:AdminDashboardComponent},
  {path:'cancel',component:CancelTicketComponent},
  {path:'Block',component:BlockFlightComponent},
  {path:'Searchbypnr',component:SearchByPnrComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
