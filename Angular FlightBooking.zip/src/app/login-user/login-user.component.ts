import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { ServeService } from '../serve.service';
import { Router } from '@angular/router';
import { FormControl, FormGroup, MaxValidator, Validators } from '@angular/forms';
@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.css']
})
export class LoginUserComponent implements OnInit {

  constructor(private AllServices:ServeService,private router:Router) { 
    
  }
  loginuserform= new FormGroup({
    email:new FormControl('',Validators.required),
    Password:new FormControl('',Validators.required)
  })
  
  ngOnInit(): void {
  }
  login(data:any){this.AllServices.login(data).subscribe((res:any) => {console.log(res)  
    
    if(res.success == 1){
      alert("Login Successful");
      localStorage.setItem('token',res.token); 
     
      localStorage.setItem('emailId',res.emailId)
     
    }
    else if(res.success==2){
      alert(res.message);
      localStorage.setItem('token',res.token); 
    localStorage.setItem('emailId',res.emailId)
    
    }
  },(error:HttpErrorResponse)=>{
    
    alert("Please check your Credentials");
    
  }
);}

}