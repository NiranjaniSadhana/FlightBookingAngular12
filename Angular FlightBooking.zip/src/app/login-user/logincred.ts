export class credis{ 
    Email!: string;
    Password!: string;
}