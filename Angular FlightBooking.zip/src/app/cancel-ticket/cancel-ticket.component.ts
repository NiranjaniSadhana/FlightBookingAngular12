import { Component, OnInit } from '@angular/core';
import { ServeService } from '../serve.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { FormControl, FormGroup, MaxValidator, Validators } from '@angular/forms';
@Component({
  selector: 'app-cancel-ticket',
  templateUrl: './cancel-ticket.component.html',
  styleUrls: ['./cancel-ticket.component.css']
})
export class CancelTicketComponent implements OnInit {

  constructor(private services:ServeService,private router:Router) { }
  Cancelform= new FormGroup({
    Pnr:new FormControl('',Validators.required),
    
  })
  ngOnInit(): void {
  }
  public Cancel(adddata:any)  {

    this.services.cancelTicket(adddata).subscribe((res:any) => {console.log(res)  
      if(res.success !=null){
        alert("cancelled successfully");  
      }
    },(error:HttpErrorResponse)=>{
      alert("cancellation failed");
    }
  );
  }
}