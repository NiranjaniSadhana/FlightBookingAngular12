import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ServeService } from './serve.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'FlightBookingSystem';
  constructor(private AllServices:ServeService,private router:Router){


  }
  ngOnInit(){}
  onloginuser(){
  this.router.navigate(['user-dashboard']);
}
onLogin(){
  this.router.navigate(['admin-dashboard']);
}
}