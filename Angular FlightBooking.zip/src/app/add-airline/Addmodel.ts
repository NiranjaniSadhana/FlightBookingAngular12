export class AddAirline{ 
    AirlineId!: string;
    Airlinename!: string;
}