import { Component, OnInit } from '@angular/core';
import { ServeService } from '../serve.service';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { FormControl, FormGroup, MaxValidator, Validators } from '@angular/forms';
@Component({
  selector: 'app-add-airline',
  templateUrl: './add-airline.component.html',
  styleUrls: ['./add-airline.component.css']
})
export class AddAirlineComponent implements OnInit {

  airlineform= new FormGroup({
    AirlineId : new FormControl('',Validators.required),
    Airlinename : new FormControl('',Validators.required)
  })

  constructor(private router:Router, private services:ServeService) { }
 
  ngOnInit(): void {
    
  }
  
  public addairline(adddata:any)  {

      this.services.AddFlight(adddata).subscribe((res:any) => {console.log(res)  
        if(res.success !=1){
          alert("Airline Added Successfully");  
        }
      },(error:HttpErrorResponse)=>{
        alert("Failed to add airline");
      }

    );
    }

}


