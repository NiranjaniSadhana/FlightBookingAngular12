import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { FormControl, FormGroup, MaxValidator, Validators } from '@angular/forms';
import { ServeService } from '../serve.service';
@Component({
  selector: 'app-schedule',
  templateUrl: './schedule.component.html',
  styleUrls: ['./schedule.component.css']
})
export class ScheduleComponent implements OnInit {
  
  scheduleForm = new FormGroup({
    FlightId: new FormControl('',Validators.required),
    FlightName: new FormControl('',Validators.required),
    Source: new FormControl('',Validators.required),
    Destination: new FormControl('',Validators.required),
    StartTime: new FormControl('',Validators.required),
    EndTime: new FormControl('',Validators.required),
    ScheduledDays: new FormControl('Daily',Validators.required),
    Bcseats: new FormControl(0,Validators.required),
    Nbcseats: new FormControl(0,Validators.required),
    Price: new FormControl(0,Validators.required),
    MealType: new FormControl(0,Validators.required),
    RoundTrip: new FormControl(0,Validators.required)
  });
  
  constructor(private router:Router, private services:ServeService) { }
  
 
  flightlist:any=[];
  

  ScheduleForm = new FormGroup({

    FlightId: new FormControl('',Validators.required),

    Flightname: new FormControl('',Validators.required),

    Source: new FormControl('',Validators.required),

    Destination: new FormControl('',Validators.required),

    StartTime: new FormControl('',Validators.required),

    EndTime: new FormControl('',Validators.required),

    

  });
  
  
  ngOnInit(): void {
  
    
  }
  

  getdata(adddata:any){
    this.services.getFlightslist(adddata).subscribe(data=>{
      this.flightlist=data;
    });
  }
  Schedule(data:any){
    this.services.AddSchedule(data).subscribe((res:any) => {console.log(res)  
          if(res.success == 1){
            alert(res.message);
            
          }
          else if(res.success == 0){
            alert(res.message);
            
          }
        },(error:HttpErrorResponse)=>{
          alert("Please Login to continue");
          
        }
      );
  }
}