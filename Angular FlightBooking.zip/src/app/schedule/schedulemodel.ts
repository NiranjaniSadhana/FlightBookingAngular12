export class ScheduleFlight{
    FlightId!:number;
    Flightname!: string;
    Source!:string;
    Destination!:string;
StartTime!:string;
EndTime!:string;

}