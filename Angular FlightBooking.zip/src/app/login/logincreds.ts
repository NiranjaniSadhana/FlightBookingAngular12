export class creds{ 
    Email!: string;
    Password!: string;
}