import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { ServeService } from '../serve.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-ticket-history',
  templateUrl: './ticket-history.component.html',
  styleUrls: ['./ticket-history.component.css']
})
export class TicketHistoryComponent implements OnInit {
  ticketHistory:any = [];
  constructor(private service:ServeService) { }

  ngOnInit(): void {
    
    this.bookingHistory(localStorage.getItem('emailId'));
    console.log(localStorage.getItem('emailId'))
   
  }

  bookingHistory(data:any){
    
 
    this.service.ticketHistory(data).subscribe((res:any) => {console.log(res)
        this.ticketHistory=res;

       
        
      },(error:HttpErrorResponse)=>{
        alert("Please Login to continue");
        
      }
    );
  }
}
