import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, observable } from 'rxjs';
import { creds } from './login/logincreds';
import { AddAirline } from './add-airline/Addmodel';
import { ScheduleFlight } from './schedule/schedulemodel';
import { BookFlight } from './booking/booking';
import { Router } from '@angular/router';
import { registercred } from './register/registercred';
import { credis } from './login-user/logincred';
@Injectable({
  providedIn: 'root'
})
export class ServeService {
public bookingHistoryURL="http://localhost:47019/api/Bookings/SearchTicket/?emailId=";
  constructor(private httpClient:HttpClient ,private router:Router) { }
  public adminlogin(data:any):Observable<any>{
    var obj=new creds();
    const headers={'content-type' :'application/json'}
    obj.Email=data.email;
    obj.Password=data.Password;
    return this.httpClient.post<any>('http://localhost:24233/api/Login/AdminLogin',JSON.stringify(obj),{'headers':headers}) 
   }
   
   public AddFlight(adddata:any):Observable<any>{
    var objaddblock= new AddAirline();
    var tokevar= localStorage.getItem('token');
     const headers={'content-type' :'application/json',Authorization:`Bearer ${tokevar}`}
  
    objaddblock.AirlineId= adddata.AirlineId;
    objaddblock.Airlinename= adddata.Airlinename;
    return this.httpClient.post<any>('http://localhost:24233/api/BlockFlight/AddFlight',JSON.stringify(objaddblock),{'headers':headers})
   }




   AddSchedule(data:any):Observable<any>{
    var jwtToken = localStorage.getItem('token');
    const headers = ({
      'content-type': 'application/json',
      Authorization: `Bearer ${jwtToken}`
    });
    return this.httpClient.post('http://localhost:24233/api/Schedule/ScheduleFlight',data, {headers:headers});
  }


   public getFlightslist(adddata:any):Observable<any>{
    var tokevar= localStorage.getItem('token');
    const headers={'content-type' :'application/json',Authorization:`Bearer ${tokevar}`}
   
    return this.httpClient.get<any>('http://localhost:47019/api/Bookings/GetAllFlights',{'headers':headers})
  }
  public BookingFlight(adddata:any):Observable<any>{
   
    var tokevar= localStorage.getItem('token');
     const headers={'content-type' :'application/json',Authorization:`Bearer ${tokevar}`}
    
     


    return this.httpClient.post<any>('http://localhost:47019/api/Bookings/FlightTicketBooking',adddata,{'headers':headers})
   }

   public searchFlight(data:any):Observable<any>{
    var tokevar = localStorage.getItem('token');
    const headers = {'content-type' :'application/json',Authorization:`Bearer ${tokevar}`}
    return this.httpClient.post('http://localhost:47019/api/Bookings/GetFlightsBySearch',data,{headers:headers});
  }
  Logout(){
    
    this.router.navigate(['./login']);
  }
  ticketHistory(emailId:string):Observable<any>{
    var jwtToken = localStorage.getItem('token');
    const headers = ({
      'content-type': 'application/json',
      Authorization: `Bearer ${jwtToken}`
    });
     
    var getURL = this.bookingHistoryURL + emailId;
    return this.httpClient.get<any>(getURL,{headers:headers});
  }
  public login(data:any):Observable<any>{
    var obj=new credis();
    const headers={'content-type' :'application/json'}
    obj.Email=data.email;
    obj.Password=data.Password;
    return this.httpClient.post<any>('http://localhost:16232/api/LoginUser/UserLogin',JSON.stringify(obj),{'headers':headers}) 
   }


   

   public Register(adddata:any):Observable<any>{
    var objaddschedule= new registercred();
    var tokevar= localStorage.getItem('token');
     const headers={'content-type' :'application/json',Authorization:`Bearer ${tokevar}`}
  
    objaddschedule.Username= adddata.Username;
    objaddschedule.Email= adddata.Email;
    objaddschedule.Password=adddata.Password;
objaddschedule.ContactNo=adddata.ContactNo;
objaddschedule.Gender=adddata.Gender;
objaddschedule.Age=adddata.Age;
objaddschedule.Address=adddata.Address;

    return this.httpClient.post<any>('http://localhost:16232/api/Registration/RegisterUser',JSON.stringify(objaddschedule),{'headers':headers})
   }
   cancelTicket(data:any):Observable<any>{
    var jwtToken = localStorage.getItem('token');
    const headers = ({
      'content-type': 'application/json',
      Authorization: `Bearer ${jwtToken}`
    });
    return this.httpClient.put('http://localhost:47019/api/Bookings/CancelTicket',JSON.stringify(data),{headers:headers});
  }
  BlockFlight(airlineId:String):Observable<any>{
    var jwtToken = localStorage.getItem('token');
    const headers = ({
      'content-type': 'application/json',
      Authorization: `Bearer ${jwtToken}`
     
    });
    return this.httpClient.delete('http://localhost:24233/api/BlockFlight/BlockFlight?Airline_ID=' + airlineId,{headers:headers});
  }
  searchTicketbypnr(Pnr:string):Observable<any>{
    var jwtToken = localStorage.getItem('token');
    const headers = ({
      'content-type': 'application/json',
      Authorization: `Bearer ${jwtToken}`
    });
    return this.httpClient.get<any>('http://localhost:47019/api/Bookings/SearchPnrTicket?Pnr='+Pnr,{headers:headers});
  }

  }


