export class registercred{
    Username!:string;
    Email!:string;
    Password!:string;
    ContactNo!:string;
    Gender!:string;
    Age!:string;
    Address!:string
}