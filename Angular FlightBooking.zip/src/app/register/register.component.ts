import { Component, OnInit } from '@angular/core';
import { ServeService } from '../serve.service';

import { HttpErrorResponse } from '@angular/common/http';
import { FormControl, FormGroup, MaxValidator, Validators } from '@angular/forms';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  Registerform= new FormGroup({
    Username : new FormControl('',Validators.required),
    Email : new FormControl('',Validators.required),
    Password: new FormControl('',Validators.required),
    ContactNo: new FormControl('',Validators.required),
    Gender : new FormControl('',Validators.required),
    Age : new FormControl('',Validators.required),
    Address: new FormControl('',Validators.required)
  })
  constructor(private services:ServeService) { }

  ngOnInit(): void {
  }

  public Register(adddata:any)  {

    this.services.Register(adddata).subscribe((res:any) => {console.log(res)  
      if(res.success !=null){
        alert("Registered Successfully");  
      }
    },(error:HttpErrorResponse)=>{
      alert("Failed to register");
    }
  );
  }

}
