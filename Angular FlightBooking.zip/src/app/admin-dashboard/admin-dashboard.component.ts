import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  onloginclick(){
    this.router.navigate(['login'])
  
  }
  onAddFlight(){
    this.router.navigate(["AddFlight"])
  }
  onScheduleFlight(){
    this.router.navigate(["Schedule"])
  }
  
  
  ontickethistory(){
    this.router.navigate(['tickethistory'])
  }
  onBlockFlight(){
    this.router.navigate(['Block'])
  }

  }
  

