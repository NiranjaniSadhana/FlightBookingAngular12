export class BookFlight{
AirlineId!:string;
BoardingTime!:string;
Username!:string;
EmailId!:string;
Name!:string;
Gender!:string;
Age!:string;
Source!:string;
Destination!:string;
MealTpe!:string;
Seatnumbers!:string
}