import { Component, OnInit } from '@angular/core';
import { ServeService } from '../serve.service';
import { HttpErrorResponse } from '@angular/common/http';
import { FormControl, FormGroup, MaxValidator, Validators } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {

  constructor(private services:ServeService,private router:Router) { }
  bookticketForm = new FormGroup({

    AirlineId: new FormControl('',Validators.required),

    BoardingTime: new FormControl('',Validators.required),

    UserName: new FormControl('',Validators.required),

    EmailId: new FormControl('',Validators.required),

    Name: new FormControl('',Validators.required),

    Gender: new FormControl('',Validators.required),

    Age: new FormControl(0,Validators.required),

    Source: new FormControl('',Validators.required),

    Destination: new FormControl('',Validators.required),

    MealTpe: new FormControl(0,Validators.required),

    SeatNumbers: new FormControl('',Validators.required)
  })
  ngOnInit(): void {
  }
  BookTicket(adddata:any){
    // console.log(data);
    this.services.BookingFlight(adddata).subscribe((res:any) => {console.log(res)  
      if(res.success == 1){
        alert(res.message);
      
      }
      else if(res.success == 0){
        alert(res.message);
      }
    },(error:HttpErrorResponse)=>{
      alert("Please Login to continue");
    }
  );
      
  }
}

