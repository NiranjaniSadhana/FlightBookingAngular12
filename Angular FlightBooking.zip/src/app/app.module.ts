import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ServeService } from './serve.service';

import { LoginComponent } from './login/login.component';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AddAirlineComponent } from './add-airline/add-airline.component';
import { BookingComponent } from './booking/booking.component';
import { ScheduleComponent } from './schedule/schedule.component';
import { SearchFlightComponent } from './search-flight/search-flight.component';
import { TicketHistoryComponent } from './ticket-history/ticket-history.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { RegisterComponent } from './register/register.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { LoginUserComponent } from './login-user/login-user.component';
import { CancelTicketComponent } from './cancel-ticket/cancel-ticket.component';

import { BlockFlightComponent } from './block-flight/block-flight.component';
import { SearchByPnrComponent } from './search-by-pnr/search-by-pnr.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AddAirlineComponent,
    BookingComponent,
    ScheduleComponent,
    SearchFlightComponent,
    TicketHistoryComponent,
    UserDashboardComponent,
    RegisterComponent,
    AdminDashboardComponent,
    LoginUserComponent,
    CancelTicketComponent,
    BlockFlightComponent,
    SearchByPnrComponent
  ],
  imports: [
    BrowserModule,
  HttpClientModule,
   FormsModule,
  ReactiveFormsModule,
    AppRoutingModule 
  ],
  providers: [ServeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
