import { Component, OnInit } from '@angular/core';
import { ServeService } from '../serve.service';
import { HttpErrorResponse } from '@angular/common/http';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-search-flight',
  templateUrl: './search-flight.component.html',
  styleUrls: ['./search-flight.component.css']
})
export class SearchFlightComponent implements OnInit {

  constructor(private service:ServeService) { }

  ngOnInit(): void {
  }
  flights:any = [];

  searchForm = new FormGroup({
    Source: new FormControl('',Validators.required),
    Destination: new FormControl('',Validators.required),
    RoundTrip: new FormControl(0,Validators.required)
  });

  SearchFlight(data:any){
    console.log(data);
    this.service.searchFlight(data).subscribe((res:any) => {console.log(res)
        if(res != null){
          this.flights = res;
        }
      },(error:HttpErrorResponse)=>{
        alert("Please Login to continue");
        this.service.Logout();
      }
    );
  }

}

